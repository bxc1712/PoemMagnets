//
//  AppData.swift
//  PoelarMagnets
//
//  Created by Daniel Martin (RIT Student) on 3/22/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import Foundation


class AppData{
    static let shared = AppData()
    
    
    let currentListKey = "listKey"
    
    var currentList:String = "colors"
    
    private var words = [
        "colors" : ["red", "green", "blue", "orange","yellow","black","white","purple","pink","gray"],
        "monsters": ["Orc", "Kirin", "Gray Ooze", "Zombie"],
        "heroes" : ["Gilgamesh", "King Arthur", "Roland", "Aragorn" , "Superman", "Batman", "Ironman"]
    ]
    
    private init(){
        readDefaultsData()
    }
    
    private func readDefaultsData(){
        let defaults = UserDefaults.standard
        if let s = defaults.object(forKey: currentListKey){
            currentList = s as! String
        } else {
            currentList = "colors"
        }
    }
    
    func fetchList(lists:String)->[String]{
        return words[lists] ?? [String]()
    }
    
    public var lists:[String]{
        return [String](words.keys)
    }
    
    public func saveDefaultsData(){
        print(#function)
        let defaults = UserDefaults.standard
        defaults.set(currentList, forKey:currentListKey)
        defaults.synchronize()
    }
}
