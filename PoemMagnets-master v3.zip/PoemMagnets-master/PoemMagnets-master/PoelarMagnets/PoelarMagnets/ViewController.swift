//
//  ViewController.swift
//  PoelarMagnets
//
//  Created by igmstu on 2/7/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import UIKit

let isPad = UIDevice.current.userInterfaceIdiom == .pad

class ViewController: UIViewController {

    let screenSize: CGRect = UIScreen.main.bounds
    
    
    @IBOutlet var area: UIView!
    @IBOutlet var listPacks: UIButton!
    
    var fontSize:CGFloat!
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        placeWords(words: AppData.shared.fetchList(lists: "\(AppData.shared.currentList)"))
        view.backgroundColor = UIColor.orange
        
        NotificationCenter.default.addObserver(self, selector: #selector(saveDefaultsData), name: NSNotification.Name.UIApplicationWillResignActive, object: nil)
        
        
    }
    
    
    func setFontSize(){
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func placeWords(words:[String]){
        var x = CGFloat(0)
        var y = CGFloat(40)
        
        if (isPad){
            fontSize = 24
        } else {
            fontSize = 12
        }
        
        //x position of previous word
        var prevX = CGFloat(0)
        //width of preious word
        var preWidth = CGFloat(0)
        
        
        for word in words{
            let l = UILabel()
            l.backgroundColor = UIColor.white
            l.text = " " + word + " "
            l.textAlignment = .center
            l.font = l.font.withSize(fontSize)
            l.sizeToFit()
            l.tag = 100
            
            //adding up for x val
            x = prevX + preWidth / 2 + l.frame.size.width / 2 + 5
            //setting the new previous width
            preWidth = l.frame.size.width
            
            //checking x bounds
            if(x < 0){
                x += 20
            }
            
            if(x > screenSize.width - l.frame.size.width / 2){
                x = 20 + l.frame.size.width / 2
                y += l.frame.size.height + 10
            }
            
            prevX = x
            
            l.center = CGPoint(x:x, y:y)
            view.addSubview(l)
            
            l.isUserInteractionEnabled = true
            let panGesture = UIPanGestureRecognizer(target: self, action: #selector(doPanGesture))
            l.addGestureRecognizer(panGesture)
        }
    }
    
    func doPanGesture(panGesture:UIPanGestureRecognizer){
        let label = panGesture.view as! UILabel
        let position = panGesture.location(in: view)
        label.center = position
    }
    
    func getLabelsInView(view: UIView) -> [UILabel] {
        var results = [UILabel]()
        for subview in view.subviews as [UIView] {
            if let labelView = subview as? UILabel {
                results += [labelView]
            } else {
                results += getLabelsInView(view: subview)
            }
        }
        return results
    }
    
    @IBAction func unwindToMain(segue: UIStoryboardSegue){
        if segue.identifier == "DoneTapped"{
            let vocabVC = segue.source as! VocabTableVCTableViewController
            let vocab = vocabVC.selectedList
            AppData.shared.currentList = vocabVC.selectedList
            print("\(AppData.shared.currentList)")
            let labels = getLabelsInView(view: area)
            
            for label in labels{
                if label.tag == 100{
                    label.removeFromSuperview()
                }
            }
            
            placeWords(words: AppData.shared.fetchList(lists: vocab))
        }
    }
    
    func saveDefaultsData(){
        AppData.shared.saveDefaultsData()
    }
}

