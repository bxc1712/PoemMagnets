//
//  UIView+takeSnapshot.swift
//  PoelarMagnets
//
//  Created by BENJAMIN CHENG (RIT Student) on 3/26/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import UIKit

extension UIView{
    func takeSnapshot() -> UIImage?{
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)
        self.drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}

