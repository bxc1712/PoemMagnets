//
//  ViewController.swift
//  PoelarMagnets
//
//  Created by igmstu on 2/7/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import UIKit

let isPad = UIDevice.current.userInterfaceIdiom == .pad

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    let screenSize: CGRect = UIScreen.main.bounds
    
    
    @IBOutlet var area: UIView!
    @IBOutlet var listPacks: UIButton!
    
    var fontSize:CGFloat!
    var bgImage:UIImage?
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        placeWords(words: AppData.shared.fetchList(lists: "\(AppData.shared.currentList)"))
        view.backgroundColor = UIColor.orange
        
        NotificationCenter.default.addObserver(self, selector: #selector(saveDefaultsData), name: NSNotification.Name.UIApplicationWillResignActive, object: nil)
    }
    
    
    func setFontSize(){
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func placeWords(words:[String]){
        var x = CGFloat(0)
        var y = CGFloat(40)
        
        if (isPad){
            fontSize = 24
        } else {
            fontSize = 12
        }
        
        //x position of previous word
        var prevX = CGFloat(0)
        //width of preious word
        var preWidth = CGFloat(0)
        
        
        for word in words{
            let l = UILabel()
            l.backgroundColor = UIColor.white
            l.text = " " + word + " "
            l.textAlignment = .center
            l.font = l.font.withSize(fontSize)
            l.sizeToFit()
            l.tag = 100
            
            //adding up for x val
            x = prevX + preWidth / 2 + l.frame.size.width / 2 + 5
            //setting the new previous width
            preWidth = l.frame.size.width
            
            //checking x bounds
            if(x < 0){
                x += 20
            }
            
            if(x > screenSize.width - l.frame.size.width / 2){
                x = 20 + l.frame.size.width / 2
                y += l.frame.size.height + 10
            }
            
            prevX = x
            
            l.center = CGPoint(x:x, y:y)
            view.addSubview(l)
            
            l.isUserInteractionEnabled = true
            let panGesture = UIPanGestureRecognizer(target: self, action: #selector(doPanGesture))
            l.addGestureRecognizer(panGesture)
        }
    }
    
    func doPanGesture(panGesture:UIPanGestureRecognizer){
        let label = panGesture.view as! UILabel
        let position = panGesture.location(in: view)
        label.center = position
    }
    
    func getLabelsInView(view: UIView) -> [UILabel] {
        var results = [UILabel]()
        for subview in view.subviews as [UIView] {
            if let labelView = subview as? UILabel {
                results += [labelView]
            } else {
                results += getLabelsInView(view: subview)
            }
        }
        return results
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("finished picking")
        let image:UIImage = info[UIImagePickerControllerEditedImage] as! UIImage
        bgImage = image
        (self.area as! UIImageView).contentMode = .center
        (self.area as! UIImageView).image = bgImage
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("cancelled")
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func unwindToMain(segue: UIStoryboardSegue){
        if segue.identifier == "DoneTapped"{
            let vocabVC = segue.source as! VocabTableVCTableViewController
            let vocab = vocabVC.selectedList
            AppData.shared.currentList = vocabVC.selectedList
            print("\(AppData.shared.currentList)")
            let labels = getLabelsInView(view: area)
            
            for label in labels{
                if label.tag == 100{
                    label.removeFromSuperview()
                }
            }
            
            placeWords(words: AppData.shared.fetchList(lists: vocab))
        }
    }
    
    @IBAction func share(_ sender: Any) {
        let image = self.view.takeSnapshot()
        let textToShare = "Check out my sick Magnet Poem DOOD!"
        let igmWebsite = NSURL(string: "http://igm.rit.edu/")
        let objectsToShare:[AnyObject] = [textToShare as AnyObject,igmWebsite!,image!]
        let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        activityVC.excludedActivityTypes = [UIActivityType.print]
        //These 3 commented out lines will help you on an iPad
        //let popoverMenuViewController = activityVC.popoverPresentationController
        //popoverMenuViewController?.permittedArrowDirection = .any
        //popoverMenuViewController?.barButtonItem = sender as? UIBarButtonItem
        self.present(activityVC, animated: true, completion: nil)
    }
    
    @IBAction func loadPhoto(_ sender: Any) {
        let imgPickerController = UIImagePickerController()
        //imgPickerController.delegate = self
        imgPickerController.allowsEditing = true
        self.present(imgPickerController, animated: true, completion: {imageP in})
    }
    
    func saveDefaultsData(){
        AppData.shared.saveDefaultsData()
    }
}

