//
//  AppData.swift
//  PoelarMagnets
//
//  Created by Daniel Martin (RIT Student) on 3/22/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import Foundation


class AppData{
    static let shared = AppData()
    
    //MARK: - Default Keys -
    let currentListKey = "listKey"

    
    //MARK: - ivars -
    var currentList:String = "success"
    private var words = [
        "Congrats" : ["I", "We", "You", "did", "were", "are", "best", "aced", "my", "your", "he", "she", "love", "rock", "at", "aced", "!", "got", "test", "homework", "won", "our", "game", "with", "great", "job", "good", "well", "it", "got"],
        "Requests": ["I", "We", "need", "don't", "have", "enough", "any", "food", "drinks", "tp", "booze", "to", "get", "remind", "me", "to"],
        "Story Time" : ["Gilgamesh", "King Arthur", "Roland", "Aragorn" , "Superman", "Batman", "Ironman", "Sauron", "The Joker", "Vampires", "Lex Luthor", "Fought", "Beat up", "Caught", "Stole", "the", "City", "Batmbile", "One Ring", "For", "Had", "Lost", "Retrieved"]
    ]
    
    private init(){
        readDefaultsData()
    }
    
    //MARK: - Functions -
    private func readDefaultsData(){
        let defaults = UserDefaults.standard
        if let s = defaults.object(forKey: currentListKey){
            currentList = s as! String
        } else {
            currentList = "colors"
        }
    }
    
    func fetchList(lists:String)->[String]{
        return words[lists] ?? [String]()
    }
    
    public var lists:[String]{
        return [String](words.keys)
    }
    
    public func saveDefaultsData(){
        print(#function)
        let defaults = UserDefaults.standard
        defaults.set(currentList, forKey:currentListKey)
        defaults.synchronize()
    }
}
