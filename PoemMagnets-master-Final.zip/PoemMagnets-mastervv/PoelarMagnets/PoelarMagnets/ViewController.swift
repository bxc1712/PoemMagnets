//
//  ViewController.swift
//  PoelarMagnets
//
//  Created by igmstu on 2/7/17.
//  Copyright © 2017 Daniel Martin. All rights reserved.
//

import UIKit

let isPad = UIDevice.current.userInterfaceIdiom == .pad

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource  {
    
    //MARK: - ivars -
    let screenSize: CGRect = UIScreen.main.bounds
    var pickerData: [String] = [String]()
    var fontSize:CGFloat!
    var currentFont:String = "HelveticaNeue"
    var bgImage:UIImage?

    //MARK: - IB Outlets -
    @IBOutlet weak var fontPicker: UIPickerView!
    @IBOutlet var listPacks: UIButton!
    @IBOutlet weak var fontSizeSlider: UISlider!
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        placeWords(words: AppData.shared.fetchList(lists: "\(AppData.shared.currentList)"))
        view.backgroundColor = UIColor.orange
        
        NotificationCenter.default.addObserver(self, selector: #selector(saveDefaultsData), name: NSNotification.Name.UIApplicationWillResignActive, object: nil)
        
        fontPicker.isHidden = !fontPicker.isHidden
        fontSizeSlider.isHidden = !fontSizeSlider.isHidden
        
        // Connect data
        self.fontPicker.delegate = self
        self.fontPicker.dataSource = self
        
        //Input data in array
        getFonts()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - Words/default save functions -
    func placeWords(words:[String]){
        var x = CGFloat(0)
        var y = CGFloat(40)
        
        if (isPad){
            fontSize = 24
        } else {
            fontSize = 12
        }
        
        //x position of previous word
        var prevX = CGFloat(0)
        //width of preious word
        var preWidth = CGFloat(0)
        
        
        for word in words{
            let l = UILabel()
            l.backgroundColor = UIColor.white
            l.text = " " + word + " "
            l.textAlignment = .center
            l.font = UIFont(name: currentFont, size:fontSize)
            l.sizeToFit()
            l.tag = 100
            
            //adding up for x val
            x = prevX + preWidth / 2 + l.frame.size.width / 2 + 5
            //setting the new previous width
            preWidth = l.frame.size.width
            
            //checking x bounds
            if(x < 0){
                x += 20
            }
            
            if(x > screenSize.width - l.frame.size.width / 2){
                x = 20 + l.frame.size.width / 2
                y += l.frame.size.height + 10
            }
            
            prevX = x
            
            l.center = CGPoint(x:0,y:0)
            view.addSubview(l)
            //Animate Word Placement
            UIView.animate(
                withDuration: 0.5,
                delay: 0.5,
                animations: {l.center = CGPoint(x:x,y:y)}
            )
            
            l.isUserInteractionEnabled = true
            let panGesture = UIPanGestureRecognizer(target: self, action: #selector(doPanGesture))
            l.addGestureRecognizer(panGesture)
        }
    }
    
    func updateWords(){
        for labels in view.subviews{
            if labels is UILabel{
                let label = labels as! UILabel
                label.font = UIFont(name: currentFont, size:fontSize)
                label.sizeToFit()
            }
        }
    }
    
    func doPanGesture(panGesture:UIPanGestureRecognizer){
        let label = panGesture.view as! UILabel
        let position = panGesture.location(in: view)
        label.center = position
    }
    
    func saveDefaultsData(){
        AppData.shared.saveDefaultsData()
    }
    
    //MARK: - Image change functions
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("finished picking")
        let image:UIImage = info[UIImagePickerControllerEditedImage] as! UIImage
        bgImage = image
        (self.view as! UIImageView).contentMode = .center
        (self.view as! UIImageView).image = bgImage
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("cancelled")
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    //MARK: - Font View Picker Delegate -
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currentFont = pickerData[row]
        updateWords()
    }
    
    //Font Function
    func getFonts(){
        for name in UIFont.familyNames {
            pickerData.append(name)
        }
    }

    
    //MARK: IB Actions
    @IBAction func unwindToMain(segue: UIStoryboardSegue){
        if segue.identifier == "DoneTapped"{
            let vocab = AppData.shared.currentList
            for labels in view.subviews{
                if labels is UILabel{
                    UIView.animate(
                        withDuration: 0.5,
                        delay: 0.5,
                        animations: {labels.center = CGPoint(x:0,y:0)},
                        completion: {(done:Bool) in labels.removeFromSuperview()}
                    )
                }
            }
            placeWords(words: AppData.shared.fetchList(lists: vocab))
        }
    }
    
    
    //MARK - Sharing Actions -
    @IBAction func share(_ sender: AnyObject) {
        let image = self.view.takeSnapshot()
        let textToShare = "Check out my sick Magnet Poem DOOD!"
        let igmWebsite = NSURL(string: "http://igm.rit.edu/")
        let objectsToShare:[AnyObject] = [textToShare as AnyObject,igmWebsite!,image!]
        let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
    }
    
    @IBAction func loadPhoto(_ sender: Any) {
        let imgPickerController = UIImagePickerController()
        imgPickerController.delegate = self
        imgPickerController.allowsEditing = true
        self.present(imgPickerController, animated: true, completion: {imageP in})
    }
    
    //MARK: - Font Change Actions
    @IBAction func changeFont(_ sender: Any) {
        fontPicker.isHidden = !fontPicker.isHidden
        fontSizeSlider.isHidden = !fontSizeSlider.isHidden
    }
    
    
    @IBAction func fontSizeChanged(_ sender: UISlider) {
        fontSize = CGFloat(sender.value)
        updateWords()
    }
    
    @IBAction func Reset(_ sender: Any) {
        let vocab = AppData.shared.currentList
        for labels in view.subviews{
            if labels is UILabel{
                UIView.animate(
                    withDuration: 0.5,
                    delay: 0.5,
                    animations: {labels.center = CGPoint(x:0,y:0)},
                    completion: {(done:Bool) in labels.removeFromSuperview()}
                )
            }
        }
        placeWords(words: AppData.shared.fetchList(lists: vocab))
    }
}

